
/* js/newfile.js */

$('.click').click(function () {
    alert('clicked');
});